#include <iostream>

using namespace std;

int main() {
    float length, width, height;
    string unit;
    
    cout << "Pyramid Volume" << endl;
    cout << "Enter length, width, height in meter: ";
    cin >> length >> width >> height >> unit;


    float volume = (length * width * height) / 3.0;

 
    if (unit == "millimeters") {
        volume *= 1000 * 1000 * 1000; 
    } else if (unit == "centimeters") {
        volume *= 100 * 100 * 100;
    } else if (unit == "kilometers") {
        volume /= 1000 * 1000 * 1000; 
    }

    cout << fixed << setprecision(3) << volume << " cubic " << unit << endl;

    return 0;
}
