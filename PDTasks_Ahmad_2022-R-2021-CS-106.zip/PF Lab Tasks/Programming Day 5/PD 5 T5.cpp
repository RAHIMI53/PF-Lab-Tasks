#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int choice;
    string productName;
    double price;
    int quantity;

    do {
        cout << "Task 05: Business Application" << endl;
        cout << "1. Enter product details" << endl;
        cout << "2. Exit" << endl;
        cout << "Choose an option: ";
        cin >> choice;

        if (choice == 1) {
            cout << "Enter product name: ";
            cin >> productName;
            cout << "Enter product price: ";
            cin >> price;
            cout << "Enter product quantity: ";
            cin >> quantity;

            double total = price * quantity;
            cout << fixed << setprecision(2);
            cout << "Product: " << productName << ", Price: $" << price << ", Quantity: " << quantity << ", Total: $" << total << endl;
        }
    } while (choice != 2);

    return 0;
}
