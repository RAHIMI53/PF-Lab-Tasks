#include <iostream>
using namespace std;

float taxCalculator(char type, float price) {
    float taxRate = 0.0;

    if (type == 'M') taxRate = 0.06; // Motorcycle
    else if (type == 'E') taxRate = 0.08; // Electric
    else if (type == 'S') taxRate = 0.10; // Sedan
    else if (type == 'V') taxRate = 0.12; // Van
    else if (type == 'T') taxRate = 0.15; // Truck

    float taxAmount = price * taxRate;
    return price + taxAmount; 
}

int main() {
    char vehicleType;
    float price;

    cout << "Task 03: Vehicle Tax Calculator" << endl;
    cout << "Enter vehicle type code (M, E, S, V, T): ";
    cin >> vehicleType;
    cout << "Enter vehicle price: ";
    cin >> price;

    float finalPrice = taxCalculator(vehicleType, price);
    cout << "The final price on a vehicle of type " << vehicleType << " after adding the tax is $" << finalPrice << "." << endl;

    return 0;
}
