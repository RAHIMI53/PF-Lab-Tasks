#include <iostream>
using namespace std;

int main() {
    char maze[5][5] = {
        {'P', ' ', ' ', 'E', ' '},
        {' ', 'E', ' ', ' ', ' '},
        {' ', ' ', ' ', ' ', ' '},
        {'E', ' ', ' ', ' ', ' '},
        {' ', ' ', ' ', ' ', ' '}
    };

    cout << "Task 06: Game Project" << endl;
    cout << "Maze Layout:" << endl;

    // Display the maze
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 5; j++) {
            cout << maze[i][j];
        }
        cout << endl;
    }


    cout << "Player (P) can move using arrow keys, and enemies (E) have defined movement patterns." << endl;

    return 0;
    system("pause");
}
