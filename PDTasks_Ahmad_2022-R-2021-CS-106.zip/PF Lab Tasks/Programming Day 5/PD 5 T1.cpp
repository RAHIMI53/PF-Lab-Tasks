#include <iostream>
using namespace std;


int globalVar = 10;

int main() {

    int localVar = 5;

    cout << "Global Variable: " << globalVar << endl; 
    cout << "Local Variable: " << localVar << endl;   
    return 0;
}
