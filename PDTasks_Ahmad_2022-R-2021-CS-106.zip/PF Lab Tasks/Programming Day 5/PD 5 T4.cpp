#include <iostream>
#include <string>
#include <cmath> 

using namespace std;

string projectTimeCalculation(int needed_hours, int days, int workers) {

    double effective_days = days * 0.9;


    int working_hours_per_day = 8 + 2; 
    int total_working_hours = static_cast<int>(floor(effective_days * working_hours_per_day * workers)); 


    if (total_working_hours >= needed_hours) {
        int hours_left = total_working_hours - needed_hours; 
        return "Yes! " + to_string(hours_left) + " hours left.";
    } else {
        int additional_hours = needed_hours - total_working_hours; 
        return "Not enough time! " + to_string(additional_hours) + " hours needed.";
    }
}

int main() {

    int needed_hours, days, workers;
    cin >> needed_hours;
    cin >> days;
    cin >> workers;


    string result = projectTimeCalculation(needed_hours, days, workers);
    cout << result << endl;

    return 0;
}
