#include <iostream>
using namespace std;

int main() {
    int days;
    cout << "Enter the number of days: ";
    cin >> days;

    int treated = 0, untreated = 0;
    int doctors = 7;

    for (int i = 1; i <= days; ++i) {
        int patients;
        cout << "Enter the number of patients for day " << i << ": ";
        cin >> patients;

        if (i % 3 == 0 && untreated > treated) {
            doctors++; // appoint a new doctor
        }

        if (patients > doctors) {
            treated += doctors;
            untreated += (patients - doctors);
        } else {
            treated += patients;
        }
    }

    cout << "Treated patients: " << treated << endl;
    cout << "Untreated patients: " << untreated << endl;

    return 0;
}
