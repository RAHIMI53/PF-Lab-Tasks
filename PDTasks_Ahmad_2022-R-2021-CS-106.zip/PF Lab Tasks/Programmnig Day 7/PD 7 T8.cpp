#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int n;
    cout << "Enter the number of cargo: ";
    cin >> n;

    int totalCargo = 0;
    double minibus = 0, truck = 0, train = 0;
    double totalCost = 0;

    for (int i = 0; i < n; ++i) {
        int weight;
        cout << "Enter the weight of cargo " << (i + 1) << ": ";
        cin >> weight;

        totalCargo += weight;

        if (weight <= 3) {
            minibus += weight;
            totalCost += weight * 200;
        } else if (weight <= 11) {
            truck += weight;
            totalCost += weight * 175;
        } else {
            train += weight;
            totalCost += weight * 120;
        }
    }

    cout << fixed << setprecision(2);
    cout << "Average price per ton: " << totalCost / totalCargo << endl;
    cout << "Percentage by minibus: " << (minibus / totalCargo) * 100 << "%" << endl;
    cout << "Percentage by truck: " << (truck / totalCargo) * 100 << "%" << endl;
    cout << "Percentage by train: " << (train / totalCargo) * 100 << "%" << endl;

    return 0;
}
