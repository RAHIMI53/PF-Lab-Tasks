#include <iostream>
using namespace std;

bool isPrime(int num) {
    if (num <= 1) return false;
    for (int i = 2; i * i <= num; ++i) {
        if (num % i == 0) return false;
    }
    return true;
}

int primorial(int n) {
    int product = 1;
    int count = 0;
    for (int i = 2; count < n; ++i) {
        if (isPrime(i)) {
            product *= i;
            count++;
        }
    }
    return product;
}

int main() {
    int n;
    cout << "Enter the value of n: ";
    cin >> n;
    cout << "The Primorial is: " << primorial(n) << endl;
    return 0;
}
