#include <iostream>
using namespace std;

int main() {
    string yearType;
    int holidays, hometownWeekends;
    cout << "Enter year type (leap/normal), number of holidays, and hometown weekends: ";
    cin >> yearType >> holidays >> hometownWeekends;

    int weekends = 48; 
    int totalGames = weekends * 3 / 4;
    totalGames += holidays * 2 / 3; 
    totalGames -= hometownWeekends; 

    if (yearType == "leap") {
        totalGames += totalGames * 15 / 100;
    }

    cout << "Total volleyball games: " << totalGames << endl;
    return 0;
}
