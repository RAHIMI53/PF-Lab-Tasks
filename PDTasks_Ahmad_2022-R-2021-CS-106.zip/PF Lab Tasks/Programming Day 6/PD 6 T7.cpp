#include <iostream>
using namespace std;

int main() {
    int examHour, examMinute, studentHour, studentMinute;
    cout << "Enter exam start hour and minute: ";
    cin >> examHour >> examMinute;
    cout << "Enter student arrival hour and minute: ";
    cin >> studentHour >> studentMinute;

    int examTime = examHour * 60 + examMinute;
    int arrivalTime = studentHour * 60 + studentMinute;
    int difference = arrivalTime - examTime;

    if (difference < -30) {
        cout << "Early";
        difference = -difference;
        if (difference >= 60) {
            cout << " " << difference / 60 << ":" << (difference % 60) << " hours before the start" << endl;
        } else {
            cout << " " << difference << " minutes before the start" << endl;
        }
    } else if (difference <= 0) {
        cout << "On time";
        if (difference < 0) {
            difference = -difference;
            if (difference >= 60) {
                cout << " " << difference / 60 << ":" << (difference % 60) << " hours before the start" << endl;
            } else {
                cout << " " << difference << " minutes before the start" << endl;
            }
        } else {
            cout << endl;
        }
    } else {
        cout << "Late";
        if (difference >= 60) {
            cout << " " << difference / 60 << ":" << (difference % 60) << " hours after the start" << endl;
        } else {
            cout << " " << difference << " minutes after the start" << endl;
        }
    }
    return 0;
}
