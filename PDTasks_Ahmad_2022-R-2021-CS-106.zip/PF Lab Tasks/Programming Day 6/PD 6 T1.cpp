#include <iostream>
using namespace std;

int main() {
    string temperature, humidity;
    cout << "Enter temperature (warm/cold): ";
    cin >> temperature;
    cout << "Enter humidity (dry/humid): ";
    cin >> humidity;

    if (temperature == "warm" && humidity == "dry") {
        cout << "Play tennis" << endl;
    } else if (temperature == "warm" && humidity == "humid") {
        cout << "Swim" << endl;
    } else if (temperature == "cold" && humidity == "dry") {
        cout << "Play basketball" << endl;
    } else if (temperature == "cold" && humidity == "humid") {
        cout << "Watch TV" << endl;
    } else {
        cout << "Invalid input" << endl;
    }
    return 0;
    system("pause");
}
