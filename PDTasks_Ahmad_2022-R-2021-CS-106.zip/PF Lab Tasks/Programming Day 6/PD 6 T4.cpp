#include <iostream>
using namespace std;

int main() {
    char serviceCode;
    int dayMinutes = 0, nightMinutes = 0;
    cout << "Enter service code (r for regular, p for premium): ";
    cin >> serviceCode;

    if (serviceCode == 'r' || serviceCode == 'R') {
        int minutes;
        cout << "Enter minutes used: ";
        cin >> minutes;
        int bill = 1000; 
        if (minutes > 50) {
            bill += (minutes - 50) * 20; 
        cout << "Regular Service: " << minutes << " minutes used. Bill: $" << bill / 100.0 << endl;
    } else if (serviceCode == 'p' || serviceCode == 'P') {
        cout << "Enter minutes used during the day: ";
        cin >> dayMinutes;
        cout << "Enter minutes used during the night: ";
        cin >> nightMinutes;

        int bill = 2500; 
        if (dayMinutes > 75) {
            bill += (dayMinutes - 75) * 10; 
        }
        if (nightMinutes > 100) {
            bill += (nightMinutes - 100) * 5;
        }
        cout << "Premium Service: " << dayMinutes + nightMinutes << " minutes used. Bill: $" << bill / 100.0 << endl;
    } else {
        cout << "Invalid service code" << endl;
    }
    return 0;
}
