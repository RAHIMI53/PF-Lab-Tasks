#include <iostream>
using namespace std;

int main() {
    string studentName;
    float marksEnglish, marksMaths, marksChemistry, marksSocialScience, marksBiology;
    cout << "Enter student name: ";
    cin >> studentName;
    cout << "Enter marks for English, Maths, Chemistry, Social Science, and Biology: ";
    cin >> marksEnglish >> marksMaths >> marksChemistry >> marksSocialScience >> marksBiology;

    float totalMarks = marksEnglish + marksMaths + marksChemistry + marksSocialScience + marksBiology;
    float average = totalMarks / 5;
    cout << "Total marks: " << totalMarks << endl;
    cout << "Average: " << average << endl;

    if (average >= 90) {
        cout << "Grade: A+" << endl;
    } else if (average >= 80) {
        cout << "Grade: A" << endl;
    } else if (average >= 70) {
        cout << "Grade: B+" << endl;
    } else if (average >= 60) {
        cout << "Grade: B" << endl;
    } else if (average >= 50) {
        cout << "Grade: C" << endl;
    } else if (average >= 40) {
        cout << "Grade: D" << endl;
    } else {
        cout << "Grade: F" << endl;
    }
    cout << "Student Name: " << studentName << endl;
    return 0;
}
