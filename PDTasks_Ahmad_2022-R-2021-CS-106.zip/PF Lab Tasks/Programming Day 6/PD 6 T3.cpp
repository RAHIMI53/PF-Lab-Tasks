#include <iostream>
using namespace std;

int main() {
    int day;
    string month;
    cout << "Enter day and month (e.g., 10 December): ";
    cin >> day >> month;

    if ((month == "March" && day >= 21) || (month == "April" && day <= 19)) {
        cout << "Zodiac Sign: Aries" << endl;
    } else if ((month == "April" && day >= 20) || (month == "May" && day <= 20)) {
        cout << "Zodiac Sign: Taurus" << endl;
    } else if ((month == "May" && day >= 21) || (month == "June" && day <= 20)) {
        cout << "Zodiac Sign: Gemini" << endl;
    } else if ((month == "June" && day >= 21) || (month == "July" && day <= 22)) {
        cout << "Zodiac Sign: Cancer" << endl;
    } else if ((month == "July" && day >= 23) || (month == "August" && day <= 22)) {
        cout << "Zodiac Sign: Leo" << endl;
    } else if ((month == "August" && day >= 23) || (month == "September" && day <= 22)) {
        cout << "Zodiac Sign: Virgo" << endl;
    } else if ((month == "September" && day >= 23) || (month == "October" && day <= 22)) {
        cout << "Zodiac Sign: Libra" << endl;
    } else if ((month == "October" && day >= 23) || (month == "November" && day <= 21)) {
        cout << "Zodiac Sign: Scorpio" << endl;
    } else if ((month == "November" && day >= 22) || (month == "December" && day <= 21)) {
        cout << "Zodiac Sign: Sagittarius" << endl;
    } else if ((month == "December" && day >= 22) || (month == "January" && day <= 19)) {
        cout << "Zodiac Sign: Capricorn" << endl;
    } else if ((month == "January" && day >= 20) || (month == "February" && day <= 18)) {
        cout << "Zodiac Sign: Aquarius" << endl;
    } else if ((month == "February" && day >= 19) || (month == "March" && day <= 20)) {
        cout << "Zodiac Sign: Pisces" << endl;
    } else {
        cout << "Invalid date" << endl;
    }
    return 0;
}
