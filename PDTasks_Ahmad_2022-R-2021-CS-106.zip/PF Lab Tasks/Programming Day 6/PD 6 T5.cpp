#include <iostream>
using namespace std;

int main() {
    string month;
    int numberOfStays;
    cout << "Enter month and number of stays: ";
    cin >> month >> numberOfStays;

    int studioPrice, apartmentPrice;

    if (month == "May" || month == "October") {
        studioPrice = 5000; 
        apartmentPrice = 6500; 
        if (numberOfStays > 14) studioPrice = studioPrice * 70 / 100; 
        else if (numberOfStays > 7) studioPrice = studioPrice * 95 / 100; 
    } else if (month == "June" || month == "September") {
        studioPrice = 7600; 
        apartmentPrice = 6870; 
        if (numberOfStays > 14) studioPrice = studioPrice * 80 / 100; 
    } else if (month == "July" || month == "August") {
        studioPrice = 7520; 
        apartmentPrice = 7700;
    } else {
        cout << "Invalid month" << endl;
        return 0;
    }

    if (numberOfStays > 14) apartmentPrice = apartmentPrice * 90 / 100;

    cout << "Apartment: " << apartmentPrice * numberOfStays / 100.0 << "$." << endl;
    cout << "Studio: " << studioPrice * numberOfStays / 100.0 << "$." << endl;
    return 0;
}
