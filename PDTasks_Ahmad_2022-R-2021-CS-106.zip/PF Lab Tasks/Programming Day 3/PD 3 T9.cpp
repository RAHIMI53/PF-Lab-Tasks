#include <iostream>
using namespace std;

int main() {
    
    int number, sum = 0;

    cout << "Enter a 4-digit number: ";
    cin >> number;

    sum += number % 10; // Last digit
    number /= 10;

    sum += number % 10; // Third digit
    number /= 10;

    sum += number % 10; // Second digit
    number /= 10;

    sum += number % 10; // First digit

    cout << "Sum of the digits: " << sum << endl;

    return 0;
}
