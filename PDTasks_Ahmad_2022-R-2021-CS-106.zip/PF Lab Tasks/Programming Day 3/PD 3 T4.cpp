#include <iostream>
using namespace std;

int main() {

    string name;
    float weight_loss_goal;
    int days_to_lose_1kg = 15; 

    cout << "Enter your name: ";
    getline(cin, name); 
    cout << "Enter your weight loss  in kilograms: ";
    cin >> weight_loss_goal;

    
    int total_days = weight_loss_goal * days_to_lose_1kg;


    cout << name << ", to lose " << weight_loss_goal 
         << " kilograms, you will need approximately " 
         << total_days << " days." << endl;

    return 0;
}
