#include <iostream>
using namespace std;

int main() {
    int n; 
    

    cout << "Enter the number of sides of the polygon: ";
    cin >> n;
    

    int sum = (n - 2) * 180;
    
    cout << "The total sum of internal angles is: " << sum << " degrees" << endl;
    
   
}
