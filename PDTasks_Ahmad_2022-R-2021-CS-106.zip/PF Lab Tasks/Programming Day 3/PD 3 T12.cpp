#include <iostream>
using namespace std;

int main() {

    int n, w, h;

    cout << "Enter the number of square meters you can paint: ";
    cin >> n;

    cout << "Enter the width of a single wall in meters: ";
    cin >> w;

    cout << "Enter the height of a single wall in meters: ";
    cin >> h;

    int area_of_wall = w * h;
    int complete_walls = n / area_of_wall;

    cout << "Number of complete walls that can be painted: " << complete_walls << endl;

    return 0;
}
