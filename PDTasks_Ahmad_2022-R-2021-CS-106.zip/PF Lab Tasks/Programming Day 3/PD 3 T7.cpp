#include <iostream>
using namespace std;

int main() {

    string movie_name;
    float adult_ticket_price, child_ticket_price;
    int adult_tickets_sold, child_tickets_sold;
    float donation_percentage;

    cout << "Enter the movie name: ";
    getline(cin, movie_name);

    cout << "Enter adult ticket price: ";
    cin >> adult_ticket_price;

    cout << "Enter child ticket price: ";
    cin >> child_ticket_price;

    cout << "Enter number of adult tickets sold: ";
    cin >> adult_tickets_sold;

    cout << "Enter number of child tickets sold: ";
    cin >> child_tickets_sold;

    cout << "Enter percentage of amount to be donated to charity: ";
    cin >> donation_percentage;

    float total_amount = (adult_ticket_price * adult_tickets_sold) + 
                         (child_ticket_price * child_tickets_sold);
    float donation_amount = total_amount * (donation_percentage / 100);
    float remaining_amount = total_amount - donation_amount;

    cout << "Remaining amount after donation: " << remaining_amount << endl;

    return 0;
}
