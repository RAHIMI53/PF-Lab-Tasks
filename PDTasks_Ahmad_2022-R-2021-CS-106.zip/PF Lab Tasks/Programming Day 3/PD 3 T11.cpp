#include <iostream>
using namespace std;

int main() {

    int age, moves;

    cout << "Enter the person's age: ";
    cin >> age;

    cout << "Enter the number of times they have moved: ";
    cin >> moves;


    float average_years = static_cast<float>(age) / (moves + 1); //

    cout << "Average number of years lived in a single house: " << average_years << endl;

    return 0;
}
