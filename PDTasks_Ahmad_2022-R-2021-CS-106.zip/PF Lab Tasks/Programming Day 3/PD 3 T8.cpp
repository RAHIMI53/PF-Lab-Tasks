#include <iostream>
using namespace std;

int main() {

    float vegetable_price, fruit_price;
    int vegetable_kg, fruit_kg;
    const float coin_to_rp = 1.94;

    cout << "Enter vegetable price per kilogram: ";
    cin >> vegetable_price;

    cout << "Enter fruit price per kilogram: ";
    cin >> fruit_price;

    cout << "Enter total kilograms of vegetables: ";
    cin >> vegetable_kg;

    cout << "Enter total kilograms of fruits: ";
    cin >> fruit_kg;

    float total_earnings_in_coins = (vegetable_price * vegetable_kg) + 
                                     (fruit_price * fruit_kg);
    float total_earnings_in_rps = total_earnings_in_coins / coin_to_rp;

    cout << "Total earnings in Rps: " << total_earnings_in_rps << endl;

    return 0;
}
