#include <iostream>
using namespace std;

int main() {

    float minutes,total_frames,total1, fps;


    cout << "Enter the number of minutes: ";
    cin >> minutes;

    cout << "Enter the frames per second : ";
    cin >> fps;


	total1 = minutes * 60 * fps;

   
    cout << "Total number of frames: " << total1 << endl;

    return 0;
}
