#include <iostream>
using namespace std;

int main() {

    float initial_velocity, acceleration, time, final_velocity;


    cout << "Please enter the initial velocity (in m/s): ";
    cin >> initial_velocity;


    cout << "Next, enter the acceleration (in m/s²): ";
    cin >> acceleration;


    cout << "Finally, enter the time (in seconds): ";
    cin >> time;


    final_velocity = initial_velocity + (acceleration * time);


    cout << "The final velocity is: " << final_velocity << " m/s" << endl;

    return 0;
}
