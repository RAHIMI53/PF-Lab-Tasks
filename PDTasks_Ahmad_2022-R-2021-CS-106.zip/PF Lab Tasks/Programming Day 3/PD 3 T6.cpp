#include <iostream>
using namespace std;

int main() {

    float bag_size, bag_cost, area_covered;

    cout << "Enter the size of the fertilizer bag in pounds: ";
    cin >> bag_size;

    cout << "Enter the cost of the bag: ";
    cin >> bag_cost;

    cout << "Enter the area in square feet that can be covered by the bag: ";
    cin >> area_covered;

    float cost_per_pound = bag_cost / bag_size;
    float cost_per_square_foot = bag_cost / area_covered;

    cout << "Cost of the fertilizer per pound: " << cost_per_pound << endl;
    cout << "Cost of fertilizing the area per square foot: " << cost_per_square_foot << endl;

    return 0;
}
