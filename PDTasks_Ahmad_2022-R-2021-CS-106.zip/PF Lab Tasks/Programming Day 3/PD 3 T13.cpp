#include <iostream>
using namespace std;

int main() {

    int num1, num2, num3, num4, num5;
    int sum;

    cout << "Enter integer 1: "; cin >> num1;
    cout << "Enter integer 2: "; cin >> num2;
    cout << "Enter integer 3: "; cin >> num3;
    cout << "Enter integer 4: "; cin >> num4;
    cout << "Enter integer 5: "; cin >> num5;


    sum = num1 + num2 + num3 + num4 + num5;

    cout << "Sum of the integers: " << sum << endl;

    return 0;
}
