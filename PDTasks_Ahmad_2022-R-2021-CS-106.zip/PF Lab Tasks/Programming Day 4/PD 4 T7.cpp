#include <iostream>
#include <iomanip> // For setprecision
using namespace std;

int main() {
    int redRoses, whiteRoses, tulips;
    cout << "Task 7: Flower Shop" << endl;
    cout << "Enter the number of red roses, white roses, and tulips: ";
    cin >> redRoses >> whiteRoses >> tulips;

    double priceRedRose = 2.00;
    double priceWhiteRose = 4.10;
    double priceTulip = 2.50;

    double totalPrice = (redRoses * priceRedRose) + (whiteRoses * priceWhiteRose) + (tulips * priceTulip);

    if (totalPrice > 200) {
        double discount = totalPrice * 0.20;
        totalPrice -= discount;
        cout << "Original Price: $" << fixed << setprecision(2) << (totalPrice + discount) << endl;
    }
    cout << "Price after Discount: $" << fixed << setprecision(2) << totalPrice << endl;

    return 0;
}
