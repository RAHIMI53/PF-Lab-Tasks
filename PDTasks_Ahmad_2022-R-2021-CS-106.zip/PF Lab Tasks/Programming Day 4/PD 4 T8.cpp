#include <iostream>
using namespace std;

int main() {
    int holidays;
    cout << "Task 8: Pet" << endl;
    cout << "Enter number of holidays: ";
    cin >> holidays;

    int workingDays = 365 - holidays;
    int gameTime = (workingDays * 63) + (holidays * 127);
    int norm = 30000;

    if (gameTime >= norm) {
        cout << "Tom sleeps well" << endl;
        cout << norm - gameTime << " minutes less for play" << endl;
    } else {
        cout << "Tom will run away" << endl;
        int difference = norm - gameTime;
        cout << difference / 60 << " hours and " << difference % 60 << " minutes for play" << endl;
    }

    return 0;
}
