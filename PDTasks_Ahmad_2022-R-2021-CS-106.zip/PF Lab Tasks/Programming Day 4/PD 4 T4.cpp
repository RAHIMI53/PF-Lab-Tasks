#include <iostream>
using namespace std;

int main() {
    int speed;
    cout << "Task 4: Check Speed" << endl;
    cout << "Enter speed: ";
    cin >> speed;

    if (speed > 100)
        cout << "Halt... YOU WILL BE CHALLENGED!!!" << endl;
    else
        cout << "Perfect! You’re going good." << endl;

    return 0;
}
