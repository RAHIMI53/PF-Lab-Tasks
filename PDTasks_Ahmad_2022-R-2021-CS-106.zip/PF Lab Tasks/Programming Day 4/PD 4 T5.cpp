#include <iostream>
using namespace std;

int main() {
    int posA, posB;
    cout << "Task 5: Possible Bonus" << endl;
    cout << "Enter your position and friend's position: ";
    cin >> posA >> posB;

    if (posB - posA <= 6)
        cout << "true" << endl;
    else
        cout << "false" << endl;

    return 0;
}
