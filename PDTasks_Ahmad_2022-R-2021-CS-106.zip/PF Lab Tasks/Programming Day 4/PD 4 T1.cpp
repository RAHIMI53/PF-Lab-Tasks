#include <iostream>
using namespace std;

int main() {
    int a, b;
    cout << "Task 1: IsEqual" << endl;
    cout << "Enter two integers: ";
    cin >> a >> b;

    if (a == b)
        cout << "true" << endl;
    else
        cout << "false" << endl;

    return 0;
}
