#include <iostream>
using namespace std;

int main() {
    int people, rolls;
    cout << "Task 9: TP Checker" << endl;
    cout << "Enter number of people and rolls of TP: ";
    cin >> people >> rolls;

    int sheetsPerRoll = 500;
    int sheetsPerDay = 57 * people;
    int totalSheets = rolls * sheetsPerRoll;
    int daysLast = totalSheets / sheetsPerDay;

    if (daysLast < 14) {
        cout << "Your TP will only last " << daysLast << " days, buy more!" << endl;
    } else {
        cout << "Your TP will last " << daysLast << " days, no need to panic!" << endl;
    }

    return 0;
}
