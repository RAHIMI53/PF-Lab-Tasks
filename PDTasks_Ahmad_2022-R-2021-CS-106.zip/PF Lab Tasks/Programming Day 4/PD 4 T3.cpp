#include <iostream>
using namespace std;

int main() {
    string country;
    double price;
    cout << "Task 3: Ticket Price" << endl;
    cout << "Enter country name: ";
    cin >> country;
    cout << "Enter ticket price: ";
    cin >> price;

    double discount = 0;
    if (country == "Pakistan") discount = 0.05;
    else if (country == "Ireland") discount = 0.10;
    else if (country == "India") discount = 0.20;
    else if (country == "England") discount = 0.30;
    else if (country == "Canada") discount = 0.45;

    double finalPrice = price * (1 - discount);
    cout << "Final price after discount: $" << finalPrice << endl;

    return 0;
}
