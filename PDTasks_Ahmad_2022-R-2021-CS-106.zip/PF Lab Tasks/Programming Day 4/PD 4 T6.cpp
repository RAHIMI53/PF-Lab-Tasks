#include <iostream>
using namespace std;

int main() {
    int hours, minutes;
    cout << "Task 6: Longest Time" << endl;
    cout << "Enter hours and minutes: ";
    cin >> hours >> minutes;

    if (hours > minutes)
        cout << hours << endl;
    else
        cout << minutes << endl;

    return 0;
}
