#include <iostream>
using namespace std;

	main() {
    cout << "       #       " << endl;
    cout << "      # #      " << endl;
    cout << "     #   #     " << endl;
    cout << "    #     #    " << endl;
    cout << "   #       #   " << endl;
    cout << "  ###########  " << endl;
    cout << " #           # " << endl;
    cout << "#             #" << endl;

    
}
