#include <iostream>
using namespace std;

	main() {
    cout << " ------------------------" << endl;
    cout << "        o  ^__^           " << endl;
    cout << "         o (oo)\\_______   " << endl;
    cout << "           (__)\\       )\\/\\ " << endl;
    cout << "                ||----w |  " << endl;
    cout << "                ||     ||  " << endl;

    
}
