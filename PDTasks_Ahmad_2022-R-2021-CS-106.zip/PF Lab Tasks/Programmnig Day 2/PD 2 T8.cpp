#include <iostream>
using namespace std;

	 main() {
    cout << "                     20 th                     " << endl;
    cout << "                C E N T U R Y                  " << endl;
    cout << "                                               " << endl;
    cout << "      **                       **              " << endl;
    cout << "     ****                     ****             " << endl;
    cout << "    ******                   ******            " << endl;
    cout << "   ********                 ********           " << endl;
    cout << "  **********               **********          " << endl;
    cout << " ************             ************         " << endl;
    cout << " **************           **************        " << endl;
    cout << "***************         ***************         " << endl;
    cout << "                 TEXT                          " << endl;
    cout << "                                               " << endl;
    cout << "                                               " << endl;
    cout << "                                               " << endl;
    cout << "_______________________________________________" << endl;

    
}
